# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_deferred_reports
from . import account_disallowed_expenses
from . import account_move
from . import bank_rec_widget_line
from . import fleet_vehicle
