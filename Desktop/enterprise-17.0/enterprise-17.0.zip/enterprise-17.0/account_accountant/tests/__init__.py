# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_account_fiscal_year
from . import test_bank_rec_widget
from . import test_bank_rec_widget_tour
from . import test_prediction
from . import test_reconciliation_matching_rules
from . import test_account_auto_reconcile_wizard
from . import test_account_reconcile_wizard
from . import test_deferred_management
from . import test_ui
