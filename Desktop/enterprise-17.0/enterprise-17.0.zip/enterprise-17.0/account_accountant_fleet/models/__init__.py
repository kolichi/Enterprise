# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_tax
from . import bank_rec_widget
from . import bank_rec_widget_line
